#!/bin/sh

echo "Running Antelope ..."
java -jar EmbeddedAntelope.jar

